# The entirety of Plants VS Zombies Day Levels in under 100kb


# Credits

## Music (NBS / MIDI)
### Karl Zuñiga
- Grasswalk : https://www.youtube.com/watch?v=HPk9AVTppHs&list=PLJ9wZfmM8_qtb9-8vUZEYu4VTdrWeO77N
- Loonboom : https://www.youtube.com/watch?v=93eF6Y3UXYU&list=PLJ9wZfmM8_qtb9-8vUZEYu4VTdrWeO77N&index=2
- converted to NBS format (Note Block Studio) and modified to remove notes outside of the game's range
### Plants Vs. Zombies (MIDI)
-  : https://www.youtube.com/watch?v=KhDHhaC2KBU

## Textures
- Assets reordered and compressed
### The Spriter's Resource
- https://www.spriters-resource.com/pc_computer/plantsvszombies/
### DeSmuME Emulator
- http://desmume.org/

## Game mechanics
- https://www.youtube.com/watch?v=JcNHpMMA_Lw
- https://plantsvszombies.wiki.gg/

## ETC
- the rest thats uncredited is mine