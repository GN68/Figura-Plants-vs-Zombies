# 50%* Rule
(The Golden Rule)
- When 50% of the current wave of zombies' hit points is depleted, the next wave spawns
- HITPOINNTS, not zombie count
- 35% - 50%, randomly generated after every wave


# Lawn Mower Rule
- Zombies will not spawn in the lane the lawn mower was triggered for 2 waves

